def status():
    """Provide information on the application health

    Args:

    Return:

    """
    return {"status": "ok"}, 200
